/***************************************************************************
* C Source File:  USBLPT.C
*
* Copyright 2001 DeVaSys
* All rights are reserved.
* No part of this document may be reproduced, stored, or transmitted in any
* form or by any means without the prior written permission of DeVaSys
*
* Description:
*
* This module contains the main function for the P.C. version of the DeVaSys
* USB firmware development kit.
*
* ........................ Revision History ................................
*
* Creation date: 02/22/2001 - Michael A. DeVault, DeVaSys
*
* Revision History Summary:
*
* Rev 1.0   22 February 2001 12:00:00   mad
*   Initial revision.
*
***************************************************************************/
#include "usbstd.h"
#include "usbrpt.h"
#include "i2c.h"

#include <stdio.h>
#include <conio.h>

void Loop(void);

BYTE volatile	byGenReport = 0;

unsigned char byTest;
const unsigned char * pbyTest1;
unsigned char * const pbyTest2;

void main(void) {

   printf("USBLPT-PD11 Cypress Mouse Emulation, Copyright 2001 DeVaSys\n");

   /* Start and/or install the USBLPT-PD11 I2C IO Driver */
   StartUSBLPTPD11Driver();

   /* Detect USBLPT-PD11 series development boards */
	if( DetectDevice(DATA) ) {
		I2C_Init();
		Loop();
	}
	else {
		printf("Error - no USBLPT-D11 detected on LPT @ 0x%03X\n\nExiting...\n\n", DATA);
	}
}

void Loop(void) {
	// main loop

	// configure USB for disconnection
	USB_Clear();

	// configure USB for connection
	USB_Init();

	do {
			if(USB_ChkIrq()) GenReport();

         if (kbhit())
         	{
             getch(); /* Clear Character */
             break;
            }
    } while (1);

	/* Configure USB for disconnection. */
  	USB_Clear();
   /* Stop Driver */
   StopUSBLPTPD11Driver();
}



