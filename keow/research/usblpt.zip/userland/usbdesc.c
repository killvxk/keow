/***************************************************************************
* C Source File:  USBDESC.C
*
* Copyright 2001 DeVaSys
* All rights are reserved.
* No part of this document may be reproduced, stored, or transmitted in any
* form or by any means without the prior written permission of DeVaSys
*
* Description:
*
* This module contains the definitions for the USB descriptors
*
* ........................ Revision History ................................
*
* Creation date: 02/22/2001 - Michael A. DeVault, DeVaSys
*
* Revision History Summary:
*
* Rev 1.0   22 February 2001 12:00:00   mad
*   Initial revision.
*
***************************************************************************/

#include "usbdesc.h"

code const USB_DEVICE_DESCRIPTOR DeviceDescr = {
	sizeof(USB_DEVICE_DESCRIPTOR),
	USB_DEVICE_DESCRIPTOR_TYPE,
	SWAPWORD(0x0110),					// usb version = 01.00 (binary coded decimal)
	0,											// class, 0xFF = Vendor Specific
	0,												// subclass
	0,												// class protocol
	EP0_PACKET_SIZE,					// max packet size for endpoint 0 (8,16,32,64)
	SWAPWORD(0x04B4),					// vendor id code (VID)
	SWAPWORD(0x0001),					// product id code (PID)
	SWAPWORD(0x0000),					// device release number = 01.00 (bcd)
	0,												// string descriptor index for manufacturer
	0,												// string descriptor index for product
	0,												// string descriptor index for serial number
	1													// number of configurations
};

code const USB_CONFIG_DATA UsbCfgData = {
	{	// configuration descriptor
		sizeof(USB_CONFIGURATION_DESCRIPTOR),
		USB_CONFIGURATION_DESCRIPTOR_TYPE,
		SWAPWORD(sizeof(USB_CONFIG_DATA)),		// total length of config
		1,												// number of interfaces supported by config
		1,												// value for set config to select this config
		0,												// string descriptor index for this config
		0x80,											// reserved1, self powered, remote wakeup
		0x32											// required bus power (* 2mA = 100mA)
	},
	{	// interface descriptor
		sizeof(USB_INTERFACE_DESCRIPTOR),
		USB_INTERFACE_DESCRIPTOR_TYPE,
		0,												// interface number (zero based index)
		0,												// alternate interface setting
		NUM_ENDPOINTS,						// number of endpoints
		3,												// class 0xFF = Vendor specific class
		0,												// subclass
		0,												// class protocol 0xFF = Vendor specific
		0													// string descriptor index for this interface
	},
	{	// HID descriptor
		sizeof(USB_HID_DESCRIPTOR),
		USB_HID_DESCRIPTOR_TYPE,
		SWAPWORD(0x0100),					// HID Class Specification compliance
		0,												// Country localization
		1,												// number of descriptors to follow
		0x22,											// and it's a report descriptor
		SWAPWORD(HID_REPORT_DESC_SIZE),		// length of report descriptor
	},
#if NUM_ENDPOINTS > 0
	{	// endpoint descriptors
		{	// EP1_IN (tx to host)
			sizeof(USB_ENDPOINT_DESCRIPTOR),
			USB_ENDPOINT_DESCRIPTOR_TYPE,
			0x81,
			USB_ENDPOINT_TYPE_INTERRUPT,
			SWAPWORD(EP1_PACKET_SIZE),
			0x0A
		}
	}
#endif
};

// cypress mouse report descriptor
code const char ReportDescr[HID_REPORT_DESC_SIZE] = {	// size = 50
		0x05, 0x01,                    // USAGE_PAGE (Generic Desktop)
		0x09, 0x02,                    // USAGE (Mouse)
		0xa1, 0x01,                    // COLLECTION (Application)
		0x09, 0x01,                    //   USAGE (Pointer)
		0xa1, 0x00,                    //   COLLECTION (Physical)
		0x05, 0x01,                    //     USAGE_PAGE (Generic Desktop)
		0x09, 0x30,                    //     USAGE (X)
		0x09, 0x31,                    //     USAGE (Y)
		0x15, 0x81,                    //     LOGICAL_MINIMUM (-127)
		0x25, 0x7f,                    //     LOGICAL_MAXIMUM (127)
		0x75, 0x08,                    //     REPORT_SIZE (8)
		0x95, 0x02,                    //     REPORT_COUNT (2)
		0x81, 0x06,                    //     INPUT (Data,Var,Rel)
		0x05, 0x09,                    //     USAGE_PAGE (Button)
		0x19, 0x01,                    //     USAGE_MINIMUM (Button 1)
		0x29, 0x03,                    //     USAGE_MAXIMUM (Button 3)
		0x15, 0x00,                    //     LOGICAL_MINIMUM (0)
		0x25, 0x01,                    //     LOGICAL_MAXIMUM (1)
		0x95, 0x03,                    //     REPORT_COUNT (3)
		0x75, 0x01,                    //     REPORT_SIZE (1)
		0x81, 0x02,                    //     INPUT (Data,Var,Abs)
		0x95, 0x01,                    //     REPORT_COUNT (1)
		0x75, 0x05,                    //     REPORT_SIZE (5)
		0x81, 0x01,                    //     INPUT (Cnst,Ary,Abs)
		0xc0,                          //   END_COLLECTION
		0xc0                           // END_COLLECTION
};

code const USB_STRING_DESCRIPTOR_LANGUAGE StrDescLanguage = {
	sizeof(USB_STRING_DESCRIPTOR_LANGUAGE),	// total descriptor byte count
	USB_STRING_DESCRIPTOR_TYPE,	// string descriptor type
	{ 0x09, 0x04 }              // descriptor string (language id = english)
};

code const USB_STRING_DESCRIPTOR_MANUFACT StrDescManufacturer = {
	sizeof(USB_STRING_DESCRIPTOR_MANUFACT),	// total descriptor byte count
	USB_STRING_DESCRIPTOR_TYPE, // string descriptor type
	{                           // descriptor string (Manufacturer)
		'C', 0x00,
		'y', 0x00,
		'p', 0x00,
		'r', 0x00,
		'e', 0x00,
		's', 0x00,
		's', 0x00
	}
};


code const USB_STRING_DESCRIPTOR_PRODUCT StrDescProduct = {
	sizeof(USB_STRING_DESCRIPTOR_PRODUCT),	// total descriptor byte count
	USB_STRING_DESCRIPTOR_TYPE, // string descriptor type
	{                           // descriptor string (product id)
		'P', 0x00,
		'r', 0x00,
		'o', 0x00,
		'd', 0x00,
		'u ', 0x00,
		'c', 0x00,
		't', 0x00,
		' ', 0x00,
		'N', 0x00,
		'a', 0x00,
		'm', 0x00,
		'e', 0x00,
	}
};


code const USB_STRING_DESCRIPTOR_CFG StrDescConfiguration = {
	sizeof(USB_STRING_DESCRIPTOR_CFG),	// total descriptor byte count
	USB_STRING_DESCRIPTOR_TYPE, // string descriptor type
	{                           // descriptor string (product id)
		'C', 0x00,
		'o', 0x00,
		'n', 0x00,
		'f', 0x00,
		'i', 0x00,
		'g', 0x00,
		'u', 0x00,
		'r', 0x00,
		'a', 0x00,
		't', 0x00,
		'i', 0x00,
		'o', 0x00,
		'n', 0x00,
		' ', 0x00,
		'N', 0x00,
		'a', 0x00,
		'm', 0x00,
		'e', 0x00
	}
};


code const USB_STRING_DESCRIPTOR_INTERFACE StrDescInterface = {
	sizeof(USB_STRING_DESCRIPTOR_INTERFACE),	// total descriptor byte count
	USB_STRING_DESCRIPTOR_TYPE, // string descriptor type
	{                           // descriptor string (product id)
		'I', 0x00,
		'n', 0x00,
		't', 0x00,
		'e', 0x00,
		'r', 0x00,
		'f', 0x00,
		'a', 0x00,
		'c', 0x00,
		'e', 0x00,
		' ', 0x00,
		'N', 0x00,
		'a', 0x00,
		'm', 0x00,
		'e', 0x00
	}
};

