/***************************************************************************
* C Source File:  USBRpt.C
*
* Copyright 2001 DeVaSys
* All rights are reserved.
* No part of this document may be reproduced, stored, or transmitted in any
* form or by any means without the prior written permission of DeVaSys
*
* Description:
*
* This module provides definitions and functions for USB HID reports
*
* ........................ Revision History ................................
*
* Creation date: 02/22/2001 - Michael A. DeVault, DeVaSys
*
* Revision History Summary:
*
* Rev 1.0   22 February 2001 12:00:00   mad
*   Initial revision.
*
***************************************************************************/
#include "usbrpt.h"
#include "usbstd.h"
#include "usbd11.h"
#include <stdio.h>

BOOL bLastReportRead = 1;
BOOL bGenData = 0;

MOUSE RptMouse = {
	0,
	0,
	0
};

REPORT Rpt[MAX_REPORTS] = {
	{ RT_INPUT, 125 }
};

void MouseDataSim(void);

void GenReport(void) {
//	if(byReportIdleTime == 0) {
		// zero, zero is a special value which means:
		// only update report on change
//	}
//	else {
		// report timer has expired, so auto-generate report data
		if(bLastReportRead) {
			// ok to update report, last report has been read
			bLastReportRead = 0;												// clear flag
         printf(" Sending Mouse Report of size %d bytes ", sizeof(RptMouse));
			D11_WrEp(D11_EP1IN_IDX, (BYTE*)&RptMouse, sizeof(RptMouse));	// write report
			MouseDataSim();
		}
//	}
}

void MouseDataSim(void) {
	// simulate mouse data

	static BYTE byState = 0;
	static WORD wCnt = 0;
	static char cDelta = 5;

	switch(byState) {
		case 0:
			// move right
			RptMouse.cX = cDelta;
			if(wCnt++ > 10) {
				byState = 1;
				wCnt = 0;
				RptMouse.cX = 0;
				RptMouse.cY = cDelta;
			}
			break;
		case 1:
			// move down
			if(wCnt++ > 10) {
				byState = 2;
				wCnt = 0;
				RptMouse.cY = 0;
				RptMouse.cX = -cDelta;
			}
			break;
		case 2:
			// move left
			if(wCnt++ > 10) {
				byState = 3;
				wCnt = 0;
				RptMouse.cX = 0;
				RptMouse.cY = -cDelta;
			}
			break;
		case 3:
			// move up
			if(wCnt++ > 10) {
				byState = 0;
				wCnt = 0;
				RptMouse.cY = 0;
				RptMouse.cX = cDelta;
			}
			break;
	}
}

