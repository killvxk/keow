/***************************************************************************
* C Source File:  USBD11.C
*
* Copyright 2001 DeVaSys
* All rights are reserved.
* No part of this document may be reproduced, stored, or transmitted in any
* form or by any means without the prior written permission of DeVaSys
*
* Description:
*
* This module provides hardware support routines for Philips PDIUSBD11
* USB interface component.
*
* ........................ Revision History ................................
*
* Creation date: 02/22/2001 - Michael A. DeVault, DeVaSys
*
* Revision History Summary:
*
* Rev 1.0   22 February 2001 12:00:00   mad
*   Initial revision.
*
***************************************************************************/
#include "usbd11.h"
#include "i2c.h"
#include <stdio.h>

BYTE D11_CmdDataI2C(BYTE byCmd, BYTE * pbyData, BYTE byCount, BYTE byRead) {
	// Writes a command byte to the D11 command register and then
	// reads or writes byCount bytes to/from the D11 data register.
	// Data is obtained from or written to pbyData.
	// A write is performed when byRead is zero, otherwise a read is performed

	I2C_Write(D11_REG_CMD, &byCmd, 1, I2C_WRMOD_NORMAL);							// Wr Cmd
	if(byCount) {
		if(byRead) {
			I2C_Read(pbyData, D11_REG_DATA, byCount);											// Rd Data
		}
		else {
			I2C_Write(D11_REG_DATA, pbyData, byCount, I2C_WRMOD_NORMAL);	// Wr Data
		}
	}
	return byCount;
}

void D11_CfgInit(void) {

	// POR Routine (from freaking web site app. note)

	BYTE Data[2];

	// disable the hub (D11 is an H11 without the HUB pins)
	Data[0] = 0x00;
	D11_CmdDataI2C(D11_CMD_POR_INIT, Data, 1, WR_DATA);

	// disable hub endpoints, enable device function endpoints
	Data[0] = 0x02;
	D11_CmdDataI2C(D11_CMD_SET_EPEN, Data, 1, WR_DATA);

	Data[0] = 0x80;
	// set device address to 0 and enable function
	D11_CmdDataI2C(D11_CMD_SET_ADDRESS, Data, 1, WR_DATA);

	// disable hub endpoints, enable device function endpoints
	Data[0] = 0x02;
	D11_CmdDataI2C(D11_CMD_SET_EPEN, Data, 1, WR_DATA);

   printf("PDIUSBD11 Reset - Configured USB waiting for Connection\n");
	// configure USB for connection
	Data[0] = 0x97;
	Data[1] = 0x02;
	D11_CmdDataI2C(D11_CMD_SET_MODE, Data, 2, WR_DATA);
}

void D11_CfgClr(void) {
	// configure USB for disconnect

	BYTE Data[2] = { 0x87, 0x0B };

	// soft - disconnect
	D11_CmdDataI2C(D11_CMD_SET_MODE, Data, 2, WR_DATA);

	// set device address to 0 and disable function
	Data[0] = 0x00;
	D11_CmdDataI2C(D11_CMD_SET_ADDRESS, Data, 1, WR_DATA);

	// disable hub and device endpoints (D11 is an H11 without the hub pins)
	Data[0] = 0x00;
	D11_CmdDataI2C(D11_CMD_SET_EPEN, Data, 1, WR_DATA);

	D11_GetIrq();

	D11_GetLtStat(D11_EP0IN_IDX);    // Get Last Transaction Status
	D11_GetLtStat(D11_EP0OUT_IDX);

	D11_GetLtStat(D11_EP1IN_IDX);
	D11_GetLtStat(D11_EP1OUT_IDX);

	D11_GetLtStat(D11_EP2IN_IDX);
	D11_GetLtStat(D11_EP2OUT_IDX);

	D11_GetLtStat(D11_EP3IN_IDX);
	D11_GetLtStat(D11_EP3OUT_IDX);
}

BYTE D11_GetLtStat(BYTE byEpIdx) {
	// get last transaction status

	BYTE byLtStat;

	D11_CmdDataI2C(D11_CMD_GET_LTSTAT + byEpIdx, &byLtStat, 1, RD_DATA);
	return byLtStat;
}

BYTE D11_GetEpStat(BYTE byEpIdx) {
	// get endpoint status

	BYTE byEpStat;

	D11_CmdDataI2C(D11_CMD_GET_EPSTAT + byEpIdx, &byEpStat, 1, RD_DATA);
	return byEpStat;
}

void D11_SetEpStall(BYTE byEpIdx) {
	// set endpoint status to stall condition

	BYTE byEpStall = 0x01;

	D11_CmdDataI2C(D11_CMD_SET_EPSTAT + byEpIdx, &byEpStall, 1, WR_DATA);
}

void D11_ClrEpStall(BYTE byEpIdx) {
	// set endpoint status to stall condition

	BYTE byEpStall = 0x00;

	D11_CmdDataI2C(D11_CMD_SET_EPSTAT + byEpIdx, &byEpStall, 1, WR_DATA);
}

void D11_AckSetup() {

	BYTE Cmds[5] = {
		D11_CMD_EP_SELECT+2,
		D11_CMD_ACK_SETUP,
		D11_CMD_CLEAR_BUF,
		D11_CMD_EP_SELECT+3,
		D11_CMD_ACK_SETUP
	};

	I2C_Write(D11_REG_CMD, Cmds, 5, I2C_WRMOD_NORMAL);						// Wr Cmds
}

WORD D11_GetIrq(void) {
	// read USB interrupt register

	WORD wIrqData;

	D11_CmdDataI2C(D11_CMD_GET_IRQ, (BYTE*)&wIrqData, 2, RD_DATA);

	return SWAPWORD(wIrqData);
}


BYTE D11_ClrEp(BYTE byEpIdx) {

	BYTE BufHeader[2];					// byte 0  = reserved, byte 1 = byte count
	BYTE byFull = 0;

	D11_CmdDataI2C(D11_CMD_EP_SELECT + byEpIdx, &byFull, 1, RD_DATA);	// ep
	if(byFull) {
		D11_CmdDataI2C(D11_CMD_READ_BUF, BufHeader, 2, RD_DATA);			// buf header
		D11_CmdDataI2C(D11_CMD_CLEAR_BUF, 0, 0, 0);										// clear buf
	}
	return BufHeader[1];
}


BYTE D11_RdEp(BYTE * pbyData, BYTE byEpIdx) {

	BYTE BufHeader[2];					// byte 0  = reserved, byte 1 = byte count
	BYTE byFull = 0;

	D11_CmdDataI2C(D11_CMD_EP_SELECT + byEpIdx, &byFull, 1, RD_DATA);	// ep
	if(byFull) {
		D11_CmdDataI2C(D11_CMD_READ_BUF, BufHeader, 2, RD_DATA);			// buf header
		if(BufHeader[1]) {
			// buffer contains data, read data from buffer
			D11_CmdDataI2C(D11_CMD_READ_BUF, pbyData, BufHeader[1], RD_DATA);
		}
		D11_CmdDataI2C(D11_CMD_CLEAR_BUF, 0, 0, 0);										// clear buf
	}
	return BufHeader[1];
}

void D11_WrEp(BYTE byEpIdx, BYTE * pbyData, BYTE byCount) {

	BYTE BufHeader[2];
	BufHeader[0] = 0x00;				// reserved always write a zero
	BufHeader[1] = byCount;			// valid byte count for data buffer

	D11_CmdDataI2C(D11_CMD_EP_SELECT + byEpIdx, 0, 0, 0);					// endpoint
	D11_CmdDataI2C(D11_CMD_WRITE_BUF, BufHeader, 2, WR_DATA);			// buf header
	if(byCount) {
		D11_CmdDataI2C(D11_CMD_WRITE_BUF, pbyData, byCount, WR_DATA);	// buf data
	}
	D11_CmdDataI2C(D11_CMD_VALID_BUF, 0, 0, 0);										// validate
}

void D11_TxNull(BYTE byEpIdx) {

	BYTE byCmd;
	BYTE BufHeader[2] = { 0x00, 0x00 };

	byCmd = D11_CMD_EP_SELECT + byEpIdx;
	I2C_Write(D11_REG_CMD, &byCmd, 1, I2C_WRMOD_NORMAL);			// Select Ep

	D11_CmdDataI2C(D11_CMD_WRITE_BUF, BufHeader, 2, WR_DATA);	// buf header

	byCmd = D11_CMD_VALID_BUF;
	I2C_Write(D11_REG_CMD, &byCmd, 1, I2C_WRMOD_NORMAL);			// Valid Buf
}
