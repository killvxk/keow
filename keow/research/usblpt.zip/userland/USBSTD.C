/***************************************************************************
* C Source File:  USBStd.C
*
* Copyright 2001 DeVaSys
* All rights are reserved.
* No part of this document may be reproduced, stored, or transmitted in any
* form or by any means without the prior written permission of DeVaSys
*
* Description:
*
* This module provides support for handling standard USB requests.
*
* ........................ Revision History ................................
*
* Creation date: 02/22/2001 - Michael A. DeVault, DeVaSys
*
* Revision History Summary:
*
* Rev 1.0   22 February 2001 12:00:00   mad
*   Initial revision.
*
***************************************************************************/
#include "usbstd.h"
#include "usbdesc.h"
#include "usbrpt.h"
#include "usbd11.h"
#include "i2c.h"
#include <stdio.h>

#define USB_UNUSED_IRQ_MASK								0xF37F

#define USB_HID_REQUEST_GET_REPORT		0x01
#define USB_HID_REQUEST_GET_IDLE			0x02
#define USB_HID_REQUEST_GET_PROTOCOL	0x03
#define USB_HID_REQUEST_SET_REPORT		0x09
#define USB_HID_REQUEST_SET_IDLE			0x0A
#define USB_HID_REQUEST_SET_PROTOCOL	0x0B

BYTE CtlDataRdBuf[8];

BYTE byUsbAddress = 0x00;
BYTE byUsbConfig = 0x00;
BYTE byUsbInterface = 0x00;
BYTE byUsbAltInterface = 0x00;
BOOL bProtocol = 0x01;

BYTE byTxCtl = 0;
BYTE byTxCtlCnt = 0;
BYTE * pbyTxCtl;

BOOL bRxCtl = 0;
BYTE byRxCtlCnt = 0;
BYTE * pbyRxCtl;

// local functions
void USB_ProcIrq(WORD wIrq);
void USB_CtlRxSetup(void);
void USB_CtlRxData(void);
void USB_CtlTx(WORD byReqCnt, WORD wActCnt);

// request handler functons
void StdDevReqHdlr(PUSB_REQUEST pSetupPkt);
void StdIntReqHdlr(PUSB_REQUEST pSetupPkt);
void StdEndReqHdlr(PUSB_REQUEST pSetupPkt);
void ClsIntReqHdlr(PUSB_REQUEST pSetupPkt);
void UsbUnspReqHdlr(PUSB_REQUEST pSetupPkt);
void StdDev_GetStatus(void);
void StdDev_GetDescr(PUSB_REQUEST pSetupPkt);
void StdDev_SetAddress(PUSB_REQUEST pSetupPkt);
void StdDev_SetConfig(PUSB_REQUEST pSetupPkt);
void StdInt_GetStatus(void);
void StdInt_GetDescr(PUSB_REQUEST pSetupPkt);
void StdInt_GetInt(PUSB_REQUEST pSetupPkt);
void StdInt_SetInterface(PUSB_REQUEST pSetupPkt);
void StdEnd_GetStatus(PUSB_REQUEST pSetupPkt);
void StdEnd_ClrFeature(PUSB_REQUEST pSetupPkt);
void StdEnd_SetFeature(PUSB_REQUEST pSetupPkt);
void ClsInt_GetReport(PUSB_REQUEST pSetupPkt);
void ClsInt_GetIdle(PUSB_REQUEST pSetupPkt);
void ClsInt_GetProtocol(void);
void ClsInt_SetReport(PUSB_REQUEST pSetupPkt);
void ClsInt_SetIdle(PUSB_REQUEST pSetupPkt);

void USB_Init(void) {

	// zero variables
	byTxCtl = 0;
	byTxCtlCnt = 0;
	byUsbAddress = 0x80;
	byUsbConfig = 0x00;
	byUsbInterface = 0x00;
	byUsbAltInterface = 0x00;

	D11_CfgInit();

	D11_WrEp(D11_EP1IN_IDX, (BYTE*)&RptMouse, sizeof(RptMouse));	// write report
}

void USB_Clear(void) {
	D11_CfgClr();
}

BYTE USB_ChkIrq(void) {

	WORD wIrq;
	BYTE byRetVal = 0;

   WaitForInterrupt();

	wIrq = D11_GetIrq();
	while(wIrq) {    								/* Keep reading and processing IRQs in queue */
    	printf("\n wIrq = 0x%04x ",wIrq);    /* until all have been processed */
		USB_ProcIrq(wIrq);
		wIrq = D11_GetIrq();
		byRetVal++;
	}
	return byRetVal;
}

void USB_ProcIrq(WORD wIrq) {

	BYTE byLtStat;

	if(wIrq & D11_INT_BUSRESET) {
		/* Bus Reset Occured - Highest Priority */
		printf(" A bus reset occured - Reinitalising PDIUSBD11\n\n");
		USB_Init();
	}
	else {

		if(wIrq & D11_INT_EP0OUT) {
			printf(" Irq - Ep0_Out (EpIdx2)");
         /* Endpoint Zero - Check if packet is Setup or Data */
			byLtStat = D11_GetLtStat(D11_EP0OUT_IDX);
			if(byLtStat & D11_LTSTAT_SETUP) USB_CtlRxSetup();
			else                            USB_CtlRxData();
		}

		if(wIrq & D11_INT_EP0IN) {
			// Ep0 In
			printf(" Irq - Ep0_In  (EpIdx3)");
			if(byTxCtl==2) { /* Interrupt Set Address */
				D11_CmdDataI2C(D11_CMD_SET_ADDRESS, &byUsbAddress, 1, WR_DATA);
				byLtStat = D11_GetLtStat(D11_EP0IN_IDX);
				printf(" Set Device Address %x", byUsbAddress);
				byTxCtl = 0;
			}
			else if(byTxCtl) {
				byLtStat = D11_GetLtStat(D11_EP0IN_IDX);
					if(byTxCtlCnt >= 8) {
               printf(" %d Sending packet of 8 bytes p=0x%X",byTxCtlCnt, pbyTxCtl);
					// Tx Next 8 bytes
					D11_WrEp(D11_EP0IN_IDX, pbyTxCtl, 8);
					pbyTxCtl+=8;
					byTxCtlCnt-=8;
				}
				else if(byTxCtlCnt == 0) {
					// Tx Null Termination packet
               printf(" Sending Null Termination Packet ");
					D11_TxNull(D11_EP0IN_IDX);
					byTxCtl = 0;
				}
				else {
					// Tx byTxCnt bytes (less than 8, more than 0)
               printf(" Sending last %d bytes at p=0x%x",byTxCtlCnt, pbyTxCtl);
					D11_WrEp(D11_EP0IN_IDX, pbyTxCtl, byTxCtlCnt);
					byTxCtl = 0;
				}
			}
			else {
				// end of transmission, status cycle
            byLtStat = D11_GetLtStat(D11_EP0IN_IDX);
            printf(" End of Transmission, Getting Status Byte %x",byLtStat);
			}
		}

		if(wIrq & USB_UNUSED_IRQ_MASK) {
			// activity on unused endpoint, clear irq
			if(wIrq & D11_INT_EP1IN) {
				// Ep1 In
				printf(" Irq - Ep1_In  (EpIdx4)");
				D11_CmdDataI2C(D11_CMD_GET_LTSTAT+D11_EP1IN_IDX,
				 &byLtStat, 1, RD_DATA);
				bLastReportRead = 1; // hid report last read
			}
			if(wIrq & D11_INT_EP1OUT) {
				// Ep1 Out
				printf(" Irq - Ep1_Out (EpIdx5)");
				D11_CmdDataI2C(D11_CMD_GET_LTSTAT+D11_EP1OUT_IDX,
				 &byLtStat, 1, RD_DATA);
			}
			if(wIrq & D11_INT_EP2IN) {
				// Ep2 In
				printf(" Irq - Ep2_In  (EpIdx7)");
				D11_CmdDataI2C(D11_CMD_GET_LTSTAT+D11_EP2IN_IDX,
				 &byLtStat, 1, RD_DATA);
			}
			if(wIrq & D11_INT_EP2OUT) {
				// Ep2 Out
				printf(" Irq - Ep2_Out (EpIdx6)");
				D11_CmdDataI2C(D11_CMD_GET_LTSTAT+D11_EP2OUT_IDX,
				 &byLtStat, 1, RD_DATA);
			}
			if(wIrq & D11_INT_EP3IN) {
				// Ep3 In
				printf(" Irq - Ep3_In  (EpIdx9)");
				D11_CmdDataI2C(D11_CMD_GET_LTSTAT+D11_EP3IN_IDX,
             &byLtStat, 1, RD_DATA);
			}
			if(wIrq & D11_INT_EP3OUT) {
				// Ep3 Out
				printf(" Irq - Ep3_Out (EpIdx8)");
				D11_CmdDataI2C(D11_CMD_GET_LTSTAT+D11_EP3OUT_IDX,
             &byLtStat, 1, RD_DATA);
			}
		}
	}
}

void USB_CtlRxSetup(void) {
	// Processes a received setup packet

	USB_REQUEST SetupPkt;
	BYTE bySelector;

	// abort any control transfers on receipt of setup packet
	byTxCtl = 0;
	byTxCtlCnt = 0;
	bRxCtl = 0;
	byRxCtlCnt = 0;

	// transfer the 8 byte Setup packet from the Control OUT endpoint to memory
	D11_RdEp((BYTE*)&SetupPkt, D11_EP0OUT_IDX);

	D11_AckSetup();						// special ACK required for setup

#ifdef __BIGENDIAN__
	SetupPkt.wValue = SWAPWORD(SetupPkt.wValue);
	SetupPkt.wIndex = SWAPWORD(SetupPkt.wIndex);
	SetupPkt.wLength = SWAPWORD(SetupPkt.wLength);
#endif

	//	x00x xxXX		valid Standard request type and recepients
	//	x01x xx01		valid Class request type and recepient for HID class
	//	x10x xxuu		valid Vendor request type and recepient
	//
	// we can use certain bits of the bmRequestType to construct a nice
	// selector value for processing the request
	bySelector = ( (SetupPkt.byReqType & 0x60) >>3 );
	bySelector |= ( SetupPkt.byReqType & 0x03);

	// analyze request using fast selector
	// good compilers will turn this into a jump table
	switch(bySelector) {
		case 0x00:
			// Standard Device request
			StdDevReqHdlr(&SetupPkt);
			break;
		case 0x01:
			// Standard Interface request
			StdIntReqHdlr(&SetupPkt);
			break;
		case 0x02:
			// Standard Endpoint request
			StdEndReqHdlr(&SetupPkt);
			break;
		case 0x03:
			// Standard Other or Reserved requests (unsupported)
			// fall through on purpose
		case 0x04:
			// Class Device request (unsupported)
			UsbUnspReqHdlr(&SetupPkt);
			break;
		case 0x05:
			// Class Interface request
			ClsIntReqHdlr(&SetupPkt);
			break;
		default:
			UsbUnspReqHdlr(&SetupPkt);
			// Class endpoint or other request
			// or Vendor requests
			// or Reserved requests (unsupported)
	}
}

void StdDevReqHdlr(PUSB_REQUEST pSetupPkt) {
	// Standard Device request

	printf(" Standard Device request - ");

	// call correct handler using jumptable and 4 bit selector

	// determine request
	switch(pSetupPkt->byRequest) {
		case USB_REQUEST_GET_STATUS:
			printf("Get Status ");
			StdDev_GetStatus();
			break;
		case USB_REQUEST_GET_DESCRIPTOR:
			printf("Get Descriptor ");
			StdDev_GetDescr(pSetupPkt);
			break;
		case USB_REQUEST_GET_CONFIGURATION:
			printf("Get Configuration ");
			D11_WrEp(D11_EP0IN_IDX, &byUsbConfig, 1);
			break;
		/* case USB_REQUEST_CLEAR_FEATURE:
			DbgWrStr("Clear Feature\n",1);
			StdDev_ClrFeature(pSetupPkt);
			break; */
		case USB_REQUEST_SET_FEATURE:
			printf("Set Feature ");
			D11_TxNull(D11_EP0IN_IDX);			// Send TxNull Packet
			break;
		case USB_REQUEST_SET_ADDRESS:
			printf("Set Address ");
			byUsbAddress = (LOBYTE(pSetupPkt->wValue) | 0x80);
			byTxCtl = 2;							// setup to set address next interrupt
			D11_TxNull(D11_EP0IN_IDX);			// Send TxNull Packet
			break;
//		case USB_REQUEST_SET_DESCRIPTOR:
//			DbgWrStr("Set Descriptor\n",1);
//			StdDev_SetDescr(pSetupPkt);
//			break;
		case USB_REQUEST_SET_CONFIGURATION:
			printf("Set Configuration ");
			StdDev_SetConfig(pSetupPkt);
			break;
		default:
			// Unsupported Request
			UsbUnspReqHdlr(pSetupPkt);
			break;
	}
}

void StdIntReqHdlr(PUSB_REQUEST pSetupPkt) {
	// Standard Interface request

	printf(" Standard Interface request - ");

	switch(pSetupPkt->byRequest) {
		case USB_REQUEST_GET_STATUS:
			printf("Get Status ");
			StdInt_GetStatus();
			break;
		case USB_REQUEST_GET_DESCRIPTOR:
			printf("Get Descriptor ");
			StdInt_GetDescr(pSetupPkt);
			break;
		case USB_REQUEST_GET_INTERFACE:
			printf("Get Interface ");
			StdInt_GetInt(pSetupPkt);
			break;
//		case USB_REQUEST_CLEAR_FEATURE:
//			DbgWrStr("Clear Feature\n",1);
//			StdInt_ClrFeature(pSetupPkt);
//			break;
		case USB_REQUEST_SET_FEATURE:
			printf("Set Feature ");
			D11_TxNull(D11_EP0IN_IDX);			// TxNull Packet
			break;
		case USB_REQUEST_SET_INTERFACE:
			printf("Set Interface ");
			StdInt_SetInterface(pSetupPkt);
			break;
		default:
			// Unsupported Request
         printf("Unsupported Request %X ",pSetupPkt->byRequest);
			UsbUnspReqHdlr(pSetupPkt);
			break;
	}
}

void StdEndReqHdlr(PUSB_REQUEST pSetupPkt) {

	printf(" Standard Endpoint request - ");

	switch(pSetupPkt->byRequest) {
		case USB_REQUEST_GET_STATUS:
			printf("Status ");
			StdEnd_GetStatus(pSetupPkt);
			break;
//		case USB_REQUEST_SYNC_FRAME:
//			DbgWrStr("Sync Frame\n",1);
//			StdEnd_SyncFrame(pSetupPkt);
//			break;
		case USB_REQUEST_CLEAR_FEATURE:
			printf("Clear Feature ");
			StdEnd_ClrFeature(pSetupPkt);
			break;
		case USB_REQUEST_SET_FEATURE:
			printf("Set Feature ");
			StdEnd_SetFeature(pSetupPkt);
			break;
		default:
			// Unsupported Request
			UsbUnspReqHdlr(pSetupPkt);
			break;
	}
}

void ClsIntReqHdlr(PUSB_REQUEST pSetupPkt) {

	printf(" Class Interface request - ");

	switch(pSetupPkt->byRequest) {
		case USB_HID_REQUEST_GET_REPORT:
			printf("Report ");
			ClsInt_GetReport(pSetupPkt);
			break;
		case USB_HID_REQUEST_GET_IDLE:
			printf("Idle ");
			ClsInt_GetIdle(pSetupPkt);
			break;
		case USB_HID_REQUEST_GET_PROTOCOL:
			printf("Protocol ");
			ClsInt_GetProtocol();
			break;
		case USB_HID_REQUEST_SET_REPORT:
			printf("Report ");
			ClsInt_SetReport(pSetupPkt);
			break;
		case USB_HID_REQUEST_SET_IDLE:
			printf("Idle ");
			ClsInt_SetIdle(pSetupPkt);
			break;
		case USB_HID_REQUEST_SET_PROTOCOL:
			printf("Protocol ");
			bProtocol = (BOOL)LOBYTE(pSetupPkt->wValue);
			D11_TxNull(D11_EP0IN_IDX);			// TxNull Packet
			break;
		default:
			// Unsupported Request
			UsbUnspReqHdlr(pSetupPkt);
			break;
	}
}

void UsbUnspReqHdlr(PUSB_REQUEST pSetupPkt) {
	// unsupported request handler
}

void StdDev_SetConfig(PUSB_REQUEST pSetupPkt) {

   printf(" Setup - Set Standard Device Configuration %x ",pSetupPkt->wValue);

	// in configured state value must be a valid configuration #
	if( LOBYTE(pSetupPkt->wValue) ) {
		// set current configuration
		byUsbConfig = LOBYTE(pSetupPkt->wValue);

	}
	else {
		// deconfiguring, device must transition to addressed state
		byUsbConfig = 0;								// clear configuration
	}

	D11_TxNull(D11_EP0IN_IDX);			// TxNull Packet
}

void StdDev_GetStatus(void) {

	BYTE TmpBuf[2] = {0x00, 0x00};
	// get device status (device), 1000 0000 = 0x80, { 0x80, 0x00 }
	D11_WrEp(D11_EP0IN_IDX, TmpBuf, 2);	// Tx Endpoint Status Packet
}


void StdDev_GetDescr(PUSB_REQUEST pSetupPkt) {
	// Get Standard Device Descriptor
	// 0x80, 0x06

	switch(HIBYTE(pSetupPkt->wValue)) {
		case 0x01:
			// get device descriptor (device)
			printf("(device) %d ", pSetupPkt->wLength);
			pbyTxCtl = (BYTE *)&DeviceDescr;
			USB_CtlTx(pSetupPkt->wLength, (WORD)DeviceDescr.bLength);
			break;

		case 0x02:
			// get configuration descriptor
			printf("(configuration) %d ",pSetupPkt->wLength);
			pbyTxCtl = (BYTE *)&UsbCfgData.ConfigDescr;
			USB_CtlTx(pSetupPkt->wLength, SWAPWORD(UsbCfgData.ConfigDescr.wTotalLength));
			break;

		case 0x03:
			// get standard device string descriptor
			// wIndex contains language identifier (ignore for now)
			// wValue contains both the Descriptor Type (Upper 8 bits)
			// and the Descriptor Index (lower 8 bits)
			printf("(string) - %x", LOBYTE(pSetupPkt->wValue));
			switch(LOBYTE(pSetupPkt->wValue)) {
				case 0x00:
					// requesting array of supported language id's
					// point to Language Descriptor structure
					pbyTxCtl = (BYTE *)&StrDescLanguage;
					USB_CtlTx(pSetupPkt->wLength, (WORD)StrDescLanguage.bLength);
					break;
				case 0x01:
					// requesting manufacturers identification string
					// point to Manufacturers identification string
					pbyTxCtl = (BYTE *)&StrDescManufacturer;
					USB_CtlTx(pSetupPkt->wLength, (WORD)StrDescManufacturer.bLength);
					break;
				case 0x02:
					// requesting product identification string
					// point to Product identification string
					pbyTxCtl = (BYTE *)&StrDescProduct;
					USB_CtlTx(pSetupPkt->wLength, (WORD)StrDescProduct.bLength);
					break;
				case 0x03:
					// requesting configuration identification string
					// point to Product identification string
					pbyTxCtl = (BYTE *)&StrDescConfiguration;
					USB_CtlTx(pSetupPkt->wLength, (WORD)StrDescConfiguration.bLength);
					break;
				case 0x04:
					// requesting interface identification string
					// point to Product identification string
					pbyTxCtl = (BYTE *)&StrDescInterface;
					USB_CtlTx(pSetupPkt->wLength, (WORD)StrDescInterface.bLength);
					break;
				default:
					// requesting unsupported string
					printf("  Error - unsupported string index ");
					break;
			}
			break;

		case 0x04:
			// LOBYTE(wValue) = 0x04
			// get standard device interface descriptor
			printf("(interface) ");
			pbyTxCtl = (BYTE *)&UsbCfgData.InterfaceDescr;
			USB_CtlTx(pSetupPkt->wLength,
			 (WORD)UsbCfgData.InterfaceDescr.bLength);
			break;

		default:
			printf("(unsupported request) ");
			break;
	}
}

void StdInt_GetStatus(void) {
	BYTE TmpBuf[2] = {0x00, 0x01};
	// get device status (interface), 1001 0000 = 0x90, { 0x81, 0x00 }
	D11_WrEp(D11_EP0IN_IDX, TmpBuf, 2);	// Tx Endpoint Status Packet
}

void StdInt_GetDescr(PUSB_REQUEST pSetupPkt) {
	// get standard interface - descriptor, 1001 0110 = 0x96, { 0x81, 0x06 }

	switch(HIBYTE(pSetupPkt->wValue)) {

		case 0x22:
			// get standard interface descriptor (report)
			printf("(report) ");
			pbyTxCtl = (BYTE *)&ReportDescr;
			USB_CtlTx(pSetupPkt->wLength, HID_REPORT_DESC_SIZE);
			break;

		case 0x21:
			// get standard interface descriptor (HID)
			printf("(HID) ");
			pbyTxCtl = (BYTE *)&UsbCfgData.HidDescr;
			USB_CtlTx(pSetupPkt->wLength, sizeof(USB_HID_DESCRIPTOR));
			break;

		default:
			printf("(unsupported request) ");
			break;
	}
}


void StdInt_GetInt(PUSB_REQUEST pSetupPkt) {
	// get standard interface - interface, 1001 1010 = 0x9A, { 0x81, 0x0A }
   //	DbgWrStr("Setup - Get Interface (interface)",1);
	if( LOBYTE(pSetupPkt->wIndex) == byUsbInterface ) {
		// request is for the currently selected interface (valid request)
		// return the currently selected alternate interface
		printf("(interface) ");
		D11_WrEp(D11_EP0IN_IDX, &byUsbAltInterface, 1);
	}
	else {
		printf("(unsupported request) ");
	}
}

void StdInt_SetInterface(PUSB_REQUEST pSetupPkt) {
	// set standard interface - interface, 0001 1011 = 0x1B, { 0x01, 0x0B }
	//	DbgWrStr("Setup - Set Standard Interface (interface)",1);
	if(byUsbConfig) {
		byUsbAltInterface = pSetupPkt->wValue;
		byUsbInterface = pSetupPkt->wIndex;
		D11_TxNull(D11_EP0IN_IDX);			// TxNull Packet
	}
	else {
		// when not configured, should respond with a request error
		// that is... no response ??
	}
}


void StdEnd_GetStatus(PUSB_REQUEST pSetupPkt) {
	// get device status (endpoint), 1010 0000 = 0xA0, { 0x82, 0x00 }
//	DbgWrStr("Setup - Get Standard Device Status (endpoint)",1);
	BYTE TmpBuf[2] = {0x00, 0x00};

	switch( LOBYTE(pSetupPkt->wIndex) ) {
		case 0x00:
			TmpBuf[0] = D11_GetEpStat(D11_EP0OUT_IDX);
			break;
		case 0x80:
			TmpBuf[0] = D11_GetEpStat(D11_EP0IN_IDX);
			break;
		case 0x81:
			TmpBuf[0] = D11_GetEpStat(D11_EP1IN_IDX);
			break;
/*
		case 0x01:
			CtlWrBuf[2] = D11_GetEpStat(D11_EP1OUT_IDX);
			break;
		case 0x02:
			CtlWrBuf[2] = D11_GetEpStat(D11_EP2OUT_IDX);
			break;
		case 0x82:
			CtlWrBuf[2] = D11_GetEpStat(D11_EP2IN_IDX);
			break;
*/
		default:
			break;
	}
	if(TmpBuf[0] & 0x08) {
		// endpoint is stalled, return 0x0001
		TmpBuf[0] = 0x01;
	}
	else {
		// endpoint is not stalled return 0x0000
		TmpBuf[0] = 0x00;
	}
	D11_WrEp(D11_EP0IN_IDX, TmpBuf, 2);	// Tx Endpoint Status Packet
}


/*
void StdEnd_SyncFrame(void) {
}
*/


void StdEnd_ClrFeature(PUSB_REQUEST pSetupPkt) {
	// clear feature (endpoint), 0010 0001 = 0x21, { 0x02, 0x01 }

//	DbgWrStr("Setup - Clear Standard Feature (endpoint)",1);

	switch( LOBYTE(pSetupPkt->wIndex) ) {
		case 0x00:
			D11_ClrEpStall(D11_EP0OUT_IDX);
			break;
		case 0x80:
			D11_ClrEpStall(D11_EP0IN_IDX);
			break;
		case 0x81:
			D11_ClrEpStall(D11_EP1IN_IDX);
			break;
/*
		case 0x01:
			D11_ClrEpStall(D11_EP1OUT_IDX);
			break;
		case 0x02:
			D11_ClrEpStall(D11_EP2OUT_IDX);
			break;
		case 0x82:
			D11_ClrEpStall(D11_EP2IN_IDX);
			break;
*/
		default:
			break;
	}
	D11_TxNull(D11_EP0IN_IDX);			// TxNull Packet
}


void StdEnd_SetFeature(PUSB_REQUEST pSetupPkt) {
	// set device feature (endpoint), 0010 0011 = 0x23, { 0x02, 0x03 }
//	DbgWrStr("Setup - Set Standard Device Feature (endpoint)",1);
	switch( LOBYTE(pSetupPkt->wIndex) ) {
		case 0x00:
			D11_SetEpStall(D11_EP0OUT_IDX);
			break;
		case 0x80:
			D11_SetEpStall(D11_EP0IN_IDX);
			break;
		case 0x81:
			D11_SetEpStall(D11_EP1IN_IDX);
			break;
/*
		case 0x01:
			D11_SetEpStall(D11_EP1OUT_IDX);
			break;
		case 0x02:
			D11_SetEpStall(D11_EP2OUT_IDX);
			break;
		case 0x82:
			D11_SetEpStall(D11_EP2IN_IDX);
			break;
*/
		default:
			break;
	}
	D11_TxNull(D11_EP0IN_IDX);			// TxNull Packet
}


void ClsInt_GetReport(PUSB_REQUEST pSetupPkt) {

	// ignore report type (hibyte of wvalue)
	switch(LOBYTE(pSetupPkt->wValue)) {
		// report ID
		case 0x01:
			// Mouse Report
			D11_WrEp(D11_EP0IN_IDX, (BYTE*)&RptMouse,
			 sizeof(RptMouse));	// write report
			break;
		default:
			break;
	}
}


void ClsInt_GetIdle(PUSB_REQUEST pSetupPkt) {
	BYTE byRptId;

	byRptId = LOBYTE(pSetupPkt->wValue);

	if( byRptId <= (MAX_REPORTS) ) {
		// valid report number
		if(Rpt[byRptId].byType == RT_INPUT) {
			// report is input, return reports idle value
			D11_WrEp(D11_EP0IN_IDX, (BYTE*)&Rpt[byRptId].byIdle, 1);
		}
		else {
			// host shouldn't be asking us for idle values of non input reports
			// but give it up anyway
			D11_WrEp(D11_EP0IN_IDX, (BYTE*)&Rpt[byRptId].byIdle, 1);
		}
	}
	else {
		// not a valid report id, return null
		D11_TxNull(D11_EP0IN_IDX);
	}
}


void ClsInt_GetProtocol(void) {
	BYTE byTemp = (BYTE)bProtocol;
	D11_WrEp(D11_EP0IN_IDX, &byTemp, 1);
}


void ClsInt_SetReport(PUSB_REQUEST pSetupPkt) {
	byRxCtlCnt = LOBYTE(pSetupPkt->wLength);
	//	pbyRxCtl = NULLPTR;
	if(byRxCtlCnt) {
		// data is coming
		bRxCtl = 1;
		switch(LOBYTE(pSetupPkt->wValue)) {
			// report ID
			case 0x01:
				// Mouse Report
				pbyRxCtl = (BYTE*)&RptMouse;
				break;
			default:
				break;
		}
	}
}


void ClsInt_SetIdle(PUSB_REQUEST pSetupPkt) {

	BYTE byRptId;
	BYTE i;

	byRptId = LOBYTE(pSetupPkt->wValue);

	if( byRptId == 0 ) {
		// 0 is flag for global idle setting of all input reports
		for(i=0; i<= MAX_REPORTS; i++) {
			if(Rpt[i].byType == RT_INPUT) {
				// report is input, set idle value
				Rpt[i].byIdle = HIBYTE(pSetupPkt->wValue);
			}
		}
	}
	else if( byRptId <= (MAX_REPORTS) ) {
		// valid report number
		if(Rpt[byRptId].byType == RT_INPUT) {
			// report is input, return reports idle value
			Rpt[byRptId].byIdle = HIBYTE(pSetupPkt->wValue);
		}
		else {
			// host shouldn't be asking us to set idle values of non input reports
			// but do it anyway
			Rpt[byRptId].byIdle = HIBYTE(pSetupPkt->wValue);
		}
	}
	else {
		// not a valid report id, error?
	}
	D11_TxNull(D11_EP0IN_IDX);
}


/*
void Ven_Get(PUSB_REQUEST pSetupPkt) {
}
*/


/*
void Ven_Set(PUSB_REQUEST pSetupPkt) {
}
*/



void USB_CtlTx(WORD wReqCnt, WORD wActCnt) {
	// transmits bytes to the host via the control endpoint

   printf("USB_CtlTx Loading first 8 bytes");

	if(wReqCnt > wActCnt) {
		// size of data is smaller than number of bytes requested
		byTxCtlCnt = wActCnt;
	}
	else {
		// size of data is equal to or greater than number of bytes requested
		byTxCtlCnt = wReqCnt;
	}
//	D11_GetLtStat(D11_EP0IN_IDX);
	if(byTxCtlCnt < 8) {
		D11_WrEp(D11_EP0IN_IDX, pbyTxCtl, byTxCtlCnt);
	}
	else {
		D11_WrEp(D11_EP0IN_IDX, pbyTxCtl, 8);
		pbyTxCtl+=8;
		byTxCtlCnt-=8;
		byTxCtl = 1;
	}
}


void USB_CtlRxData(void) {
	BYTE byRead;


	if(bRxCtl) {
		printf(" P R O C E S S   D A T A   C A L L");
		// receiving control data
		if(pbyRxCtl != NULLPTR) {
			byRead = D11_RdEp(pbyRxCtl, D11_EP0OUT_IDX);
		}
		else {
			// just clear the buffer
			byRead = D11_ClrEp(D11_EP0OUT_IDX);
		}
		if(byRead > byRxCtlCnt) {
			// ouch, got more than we were expecting
			bRxCtl = 0;
			byRxCtlCnt = 0;
			D11_TxNull(D11_EP0IN_IDX);	// TxNull Packet
		}
		else if(byRead == byRxCtlCnt) {
			// got the last of it
			bRxCtl = 0;
			byRxCtlCnt = 0;
			printf(" Got the report data!");
			D11_TxNull(D11_EP0IN_IDX);	// TxNull Packet
		}
		else {
			// more to come
			byRxCtlCnt -= byRead;
			if(pbyRxCtl != NULLPTR) {
				pbyRxCtl += byRead;
			}
		}
	}
	else {
		printf(" RdEpIdx02 Null { 0x00, 0x00 } ");
	}
}


