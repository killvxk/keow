The bootstrap folder contains a small version of each OS.
Just enough to be able to mount media to install a larger
version.
